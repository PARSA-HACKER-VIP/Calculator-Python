# Calculator-in-python3-Mohammad Parsa Mirloo

# Author :

ooo        ooooo ooooo ooooooooo.   ooooo          .oooooo.     .oooooo.   
`88.       .888' `888' `888   `Y88. `888'         d8P'  `Y8b   d8P'  `Y8b  
 888b     d'888   888   888   .d88'  888         888      888 888      888 
 8 Y88. .P  888   888   888ooo88P'   888         888      888 888      888 
 8  `888'   888   888   888`88b.     888         888      888 888      888 
 8    Y     888   888   888  `88b.   888       o `88b    d88' `88b    d88' 
o8o        o888o o888o o888o  o888o o888ooooood8  `Y8bood8P'   `Y8bood8P'  


# Homework - Uploaded in Git Hub :D